import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

import 'calorie_tracker/calorie_tracker_page.dart';
import 'firebase_options.dart';
import 'ingredients/ingredients_page.dart';
import 'ingredients/ingredients_repository.dart';
import 'spoonacular/recipe_summary.dart';
import 'spoonacular/spoonacular_api.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Recipe Finder',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: colorScheme.inversePrimary,
        title: const Text('Recipe Finder'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                'Plan meals, discover recipes, and save your favorites.',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 12),
              Text(
                'Search Spoonacular to find new ideas for breakfast, lunch, or dinner.',
                style: Theme.of(context).textTheme.bodyLarge,
              ),
              const Spacer(),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => const RecipePage(),
                      ),
                    );
                  },
                  child: const Text('Go to Search'),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => const IngredientsPage(),
                      ),
                    );
                  },
                  child: const Text('Add Ingredients'),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => const CalorieTrackerPage(),
                      ),
                    );
                  },
                  child: const Text('Track Calories'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class RecipePage extends StatefulWidget {
  const RecipePage({super.key});

  @override
  State<RecipePage> createState() => _RecipePageState();
}

class _RecipePageState extends State<RecipePage> {
  final TextEditingController _controller = TextEditingController();
  final SpoonacularApi _api = SpoonacularApi();

  List<RecipeSummary> _results = <RecipeSummary>[];
  bool _isLoading = false;
  String? _errorMessage;

  Future<void> _search() async {
    final query = _controller.text.trim();
    final ingredients = IngredientsRepository.instance.ingredients;
    if (query.isEmpty && ingredients.isEmpty) {
      setState(() {
        _errorMessage = null;
        _results = <RecipeSummary>[];
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    List<RecipeSummary> nextResults = <RecipeSummary>[];
    String? nextError;

    try {
      nextResults = await _api.searchRecipes(
        query,
        includeIngredients: ingredients,
      );
    } catch (error) {
      nextError = error.toString();
      nextResults = <RecipeSummary>[];
    }

    if (!mounted) {
      return;
    }

    setState(() {
      _results = nextResults;
      _errorMessage = nextError;
      _isLoading = false;
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _api.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ingredients = IngredientsRepository.instance.ingredients;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: const Text('Recipe Finder'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: <Widget>[
              Row(
                children: <Widget>[
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      textInputAction: TextInputAction.search,
                      onSubmitted: (_) => _search(),
                      decoration: const InputDecoration(
                        labelText: 'Search recipes',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  ElevatedButton(
                    onPressed: _isLoading ? null : _search,
                    child: _isLoading
                        ? const SizedBox(
                            height: 18,
                            width: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Text('Search'),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              if (ingredients.isNotEmpty)
                Align(
                  alignment: Alignment.centerLeft,
                  child: Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: ingredients
                        .map((ingredient) => Chip(label: Text(ingredient)))
                        .toList(),
                  ),
                ),
              if (ingredients.isNotEmpty) const SizedBox(height: 16),
              if (_errorMessage != null)
                Text(
                  _errorMessage!,
                  style: TextStyle(color: Theme.of(context).colorScheme.error),
                ),
              if (_results.isEmpty && !_isLoading && _errorMessage == null)
                Text(
                  ingredients.isEmpty
                      ? 'Start by searching for a recipe.'
                      : 'Search by keyword or adjust your ingredient filters.',
                ),
              if (_results.isNotEmpty)
                Expanded(
                  child: ListView.separated(
                    itemCount: _results.length,
                    separatorBuilder: (context, index) =>
                        const Divider(height: 24),
                    itemBuilder: (context, index) {
                      final recipe = _results[index];
                      return ListTile(
                        leading: recipe.imageUrl.isEmpty
                            ? const Icon(Icons.restaurant_menu)
                            : ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: Image.network(
                                  recipe.imageUrl,
                                  width: 56,
                                  height: 56,
                                  fit: BoxFit.cover,
                                  errorBuilder: (context, error, stackTrace) =>
                                      const Icon(Icons.restaurant_menu),
                                ),
                              ),
                        title: Text(recipe.title),
                        subtitle: Text('Recipe ID: ${recipe.id}'),
                      );
                    },
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
